<?php 
$DatabaseType = 'mysql'; 
?>