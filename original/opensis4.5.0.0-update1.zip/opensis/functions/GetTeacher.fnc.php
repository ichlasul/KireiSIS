<?php
#**************************************************************************
#  openSIS is a free student information system for public and non-public 
#  schools from Open Solutions for Education, Inc. web: www.os4ed.com
#
#  openSIS is  web-based, open source, and comes packed with features that 
#  include student demographic info, scheduling, grade book, attendance, 
#  report cards, eligibility, transcripts, parent portal, 
#  student portal and more.   
#
#  Visit the openSIS web site at http://www.opensis.com to learn more.
#  If you have question regarding this system or the license, please send 
#  an email to info@os4ed.com.
#
#  This program is released under the terms of the GNU General Public License as  
#  published by the Free Software Foundation, version 2 of the License. 
#  See license.txt.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#***************************************************************************************
function GetTeacher($teacher_id,$title='',$column='FULL_NAME',$schools=true)
{	global $_CENTRE;
	
	if(!$_CENTRE['GetTeacher'])
	{
		$QI=DBQuery("SELECT STAFF_ID,CONCAT(LAST_NAME,', ',FIRST_NAME) AS FULL_NAME,USERNAME,PROFILE FROM STAFF WHERE SYEAR='".UserSyear()."'".($schools?" AND SCHOOLS LIKE '%,".UserSchool().",%'":''));
		$_CENTRE['GetTeacher'] = DBGet($QI,array(),array('STAFF_ID'));
	}
	
	return $_CENTRE['GetTeacher'][$teacher_id][1][$column];
}
?>
