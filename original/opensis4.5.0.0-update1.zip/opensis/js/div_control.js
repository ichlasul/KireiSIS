// JavaScript Document
function hidediv() 
{ 
	if (document.getElementById) 
	{ 
		document.getElementById("hideShow").style.display = "none";
	} 
} 

function showdiv() 
{ 
	if (document.getElementById) 
	{ 
		document.getElementById("hideShow").style.display = "block";
	} 
} 

function prim_hidediv() 
{ 
	if (document.getElementById) 
	{ 
		document.getElementById("prim_hideShow").style.display = "none";
	} 
} 

function prim_showdiv() 
{ 
	if (document.getElementById) 
	{ 
		document.getElementById("prim_hideShow").style.display = "block";
	} 
} 

function sec_hidediv() 
{ 
	if (document.getElementById) 
	{ 
		document.getElementById("sec_hideShow").style.display = "none";
	} 
} 

function sec_showdiv() 
{ 
	if (document.getElementById) 
	{ 
		document.getElementById("sec_hideShow").style.display = "block";
	} 
} 

function addn_hidediv() 
{ 
	if (document.getElementById) 
	{ 
		document.getElementById("addn_hideShow").style.display = "none";
	} 
} 

function addn_showdiv() 
{ 
	if (document.getElementById) 
	{ 
		document.getElementById("addn_hideShow").style.display = "block";
	} 
}


