<?php
$menu['Food_Service']['admin'] = array(
						'Food_Service/Accounts.php'=>get_string('accounts', 'Food_Service/Menu'),
						'Food_Service/Statements.php'=>get_string('statements', 'Food_Service/Menu'),
						'Food_Service/Transactions.php'=>get_string('transactions', 'Food_Service/Menu'),
						'Food_Service/ServeMenus.php'=>get_string('serveMeals', 'Food_Service/Menu'),
						1=>get_string('reports', 'Food_Service/Menu'),
						'Food_Service/ActivityReport.php'=>get_string('activityReport', 'Food_Service/Menu'),
						'Food_Service/TransactionsReport.php'=>get_string('transactionsReport', 'Food_Service/Menu'),
						'Food_Service/MenuReports.php'=>get_string('mealReports', 'Food_Service/Menu'),
						'Food_Service/Reminders.php'=>get_string('reminders', 'Food_Service/Menu'),
						2=>get_string('setup', 'Food_Service/Menu'),
						'Food_Service/DailyMenus.php'=>get_string('dailyMenus', 'Food_Service/Menu'),
						'Food_Service/MenuItems.php'=>get_string('mealItems', 'Food_Service/Menu'),
						'Food_Service/Menus.php'=>get_string('meals', 'Food_Service/Menu'),
						'Food_Service/Kiosk.php'=>get_string('kioskPreview', 'Food_Service/Menu')
//						3=>'Utilities',
//						'Food_Service/AssignSchool.php'=>'Assign School'
					);

$menu['Food_Service']['teacher'] = array(
						'Food_Service/Accounts.php'=>get_string('accounts', 'Food_Service/Menu'),
						'Food_Service/Statements.php'=>get_string('statements', 'Food_Service/Menu'),
						1=>get_string('setup', 'Food_Service/Menu'),
						'Food_Service/DailyMenus.php'=>get_string('dailyMenus', 'Food_Service/Menu'),
						'Food_Service/MenuItems.php'=>get_string('mealItems', 'Food_Service/Menu')
					);

$menu['Food_Service']['parent'] = array(
						'Food_Service/Accounts.php'=>get_string('accounts', 'Food_Service/Menu'),
						'Food_Service/Statements.php'=>get_string('statements', 'Food_Service/Menu'),
						1=>get_string('setup', 'Food_Service/Menu'),
						'Food_Service/DailyMenus.php'=>get_string('dailyMenus', 'Food_Service/Menu'),
						'Food_Service/MenuItems.php'=>get_string('mealItems', 'Food_Service/Menu')
					);

$exceptions['Food_Service'] = array(
						'Food_Service/ServeMenus.php'=>true
					);
?>
