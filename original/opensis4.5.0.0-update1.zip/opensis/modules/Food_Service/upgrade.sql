ALTER TABLE food_service_transactions ADD COLUMN school_id numeric;
ALTER TABLE food_service_staff_transactions ADD COLUMN school_id numeric;
