<?php
define('LANG_RECORDS_ADDED_CONFIRMATION','Absence records were added for the selected students.');
define('LANG_CHOOSE_STUDENT_ERROR','You must choose at least one period and one student.');
define('LANG_SUBMIT_BUTTON','Add Absences to Selected Students');
define('LANG_ADD_ABSENCE_TO_PERIODS','Add Absence to Periods');
define('LANG_ABSENCE_CODE','Absence Code');
define('LANG_ABSENCE_REASON','Absence Reason');


?>