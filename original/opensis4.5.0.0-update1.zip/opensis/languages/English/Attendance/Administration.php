<?php
define('LANG_UPDATE','Update');
define('LANG_COURSE','Course');
define('LANG_COURSES','Courses');
define('LANG_HOME_PHONE','Home Phone');
define('LANG_THIS_STUDENT_HAS_NO_CONTACT_INFORMATION_','This student has no contact information.');
define('LANG_CONTACT_INFORMATION','Contact Information');
define('LANG_ALL','All');
define('LANG_CURRRENT_STUDENT','Current Student');

?>